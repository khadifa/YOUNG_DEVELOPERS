package system.traffic.system_traffic2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SystemTraffic2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
